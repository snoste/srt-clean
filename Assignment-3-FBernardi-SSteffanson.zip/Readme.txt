It is possible to change the line to run on each thread by changing the variable at the beginning of main.
This folder contains the report and two folders with the triple A9 CPU and A9A15 CPU. We did not include previous version of improvements because they are very similar to these once, only worse.
This report has been made by Filippo Bernardi and Snorri Stefansson.
