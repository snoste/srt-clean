make clean
make
./srt
gnome-open res.ppm
