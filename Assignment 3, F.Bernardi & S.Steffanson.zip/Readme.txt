It is possible to change the line runned in each thread by changing the variable at the beginning of the code.
This folder contain the report and two file for the triple A3 CPU and A15 CPU. We did not incluse previous code that were basically the same as the one on the folder.
This report has been made by Filippo Bernardi and Snorri Steffanson.